# :nut_and_bolt: Components of Freak Cloud

Freak Cloud consists of five main components:

* Freak Cloud Nodes
* zkEVM Smart Contract
* Merkle tree-based storage proof
* Incentivization and anti-fraud model on ZkEVM
* Order book storage price on ZkEVM
