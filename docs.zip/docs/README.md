<div align="center">
  <img style="width: 100%;" src="./banner.jpg" />
</div>


# :wave: Introduction

Freak Cloud is the first decentralized data storage dApp built on the zkEVM of zkSync, entirely driven by community.

Freak Cloud facilitates data transfers and storage between users and storage provider nodes, seamlessly integrating an on-chain protocol on zkSync. This protocol features Merkle-tree based cryptographic proofs and an incentivization model to guarantee top-notch quality, security, and transparency for data storage and transfers

Individuals can join Freak Cloud as either users seeking data storage or as storage providers aiming to earn rewards. Users upload their data to Freak Cloud, where it is encrypted and stored in a decentralized manner by data providers. The storage price is genuinely determined by user demand and storage provider supply, and anyone can become a storage provider, preserving the platform's decentralized nature.

As a dApp within the zk-rollup environment of zkSync, combined with cryptographic storage proofs such as Merkle-tree based proofs, Freak Cloud interactions are processed on zkSync with ultra-fast speeds and minimal gas fees without compromising security or transparency.
