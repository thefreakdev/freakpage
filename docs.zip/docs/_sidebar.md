<div align="center">
  <img style="width: 50%;" src="./logo.jpg" />
</div>

* [:wave: **Introduction**](./)

* [:scroll: **Vision and Roadmap**](./vision_and_roadmap/)

* [:confused: **Problems with Existing Data Storage Solutions**](./problems/)

* [:detective: **How Freak Cloud works**](./how_it_works/)

* [:exploding_head: **Why doesn't Freak Cloud require a Layer 1 solution like Filecoin or Arweave to function?**](./no_layer_one/)

* [:nut_and_bolt: **Components of Freak Cloud**](./components/)

  * [:desktop_computer: **Freak Cloud Nodes**](./components/nodes.md)
  * [:bookmark_tabs: **Order Book for Storage Price on zkEVM**](./components/pricing.md)
  * [🧾 **zkEVM Smart Contract**](./components/zkevm_contract.md)
  * [👨‍💻 **Cryptographic Data Storage Proof**](./components/proof.md)
    * [**Merkle Tree-Based Proof**](./components/merkle/)
  * [:moneybag: **Incentivization and anti-fraud model on ZkEVM**](./components/incentivization.md)

* [:medal_sports: **Comparing Freak Cloud to Other Data Storage Solutions**](./comparison/)

* [:dollar: **Tokenomics (coming soon)**]()
