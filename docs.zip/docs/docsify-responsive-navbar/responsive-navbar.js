window.$docsify.plugins = [].concat(installResponsiveNavbar, window.$docsify.plugins);

function installResponsiveNavbar(hook, vm) {
  hook.mounted(function () {
    // Create custom navbar
    var customNavbar = document.createElement('div');
    customNavbar.className = 'custom-navbar';
    customNavbar.innerHTML = `
      <div align="center">
        <a href="./"><img src="./logo.jpg" /></a>
      </div>
      <ul>
        <li><a href="./">👋 Introduction</a></li>
        <li><a href="./vision_and_roadmap/">📜 Vision and Roadmap</a></li>
        <li><a href="./problems/">😕 Problems with Existing Data Storage Solutions</a></li>
        <li><a href="./how_it_works/">🕵️ How Freak Cloud works</a></li>
        <li><a href="./no_layer_one/">💥 Why doesn't Freak Cloud require a Layer 1 solution like Filecoin or Arweave to function?</a></li>
        <li><a href="./components/">🔩 Components of Freak Cloud</a></li>
      </ul>
    `;
    document.body.appendChild(customNavbar);

    // Create responsive navbar button
    var responsiveNavButton = document.createElement('button');
    responsiveNavButton.className = 'responsive-nav-button';
    responsiveNavButton.setAttribute('type', 'button');
    responsiveNavButton.innerHTML = '&#9776;';

    responsiveNavButton.addEventListener('click', function () {
      var nav = document.querySelector('.responsive-navbar');
      if (nav.className === 'responsive-navbar') {
        nav.className += ' responsive';
      } else {
        nav.className = 'responsive-navbar';
      }
    });

    document.body.appendChild(responsiveNavButton);

    // Create responsive navbar
    var responsiveNavbar = document.createElement('div');
    responsiveNavbar.className = 'responsive-navbar';
    responsiveNavbar.innerHTML = `
      <div align="center">
        <img style="width: 50%;" src="./logo.jpg" />
      </div>
      <ul>
        <li><a href="./">👋 Introduction</a></li>
        <li><a href="./vision_and_roadmap/">📜 Vision and Roadmap</a></li>
        <li><a href="./problems/">😕 Problems with Existing Data Storage Solutions</a></li>
        <li><a href="./how_it_works/">🕵️ How Freak Cloud works</a></li>
        <li><a href="./no_layer_one/">💥 Why doesn't Freak Cloud require a Layer 1 solution like Filecoin or Arweave to function?</a></li>
        <li><a href="./components/">🔩 Components of Freak Cloud</a></li>
      </ul>
    `;

    document.body.appendChild(responsiveNavbar);
  });

  hook.doneEach(function () {
    var nav = document.querySelector('.responsive-navbar');
    if (nav.className.indexOf('responsive') !== -1) {
      nav.className = 'responsive-navbar';
    }
  });
}
