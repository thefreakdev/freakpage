# :detective: How Freak Cloud works

Freak Cloud is a decentralized data storage dApp built on the zkEVM of zkSync, connecting users seeking storage with anyone willing to provide storage to earn rewards, while ensuring a secure, transparent, and decentralized process.

Freak Cloud integrates an order book of storage prices into a dApp running on zkEVM, where storage providers set their desired compensation, and users set their preferred payment. Users are then paired with random storage providers at the agreed-upon price. Freak Cloud facilitates data transfers and storage between users and providers through Freak Cloud nodes while employing an on-chain protocol on zkSync and cryptographic Merkle-tree based proofs to guarantee quality, transparency, decentralization, and security.
